package com.example.demoApi2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApi2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.demoApi3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApi3Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoApi3Application.class, args);
	}

}
